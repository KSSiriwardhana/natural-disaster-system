// eslint-disable-next-line no-unused-vars
import React from "react";

const FooterComponent = () => {
  return (
    <div>
      <footer className="footer">
        <span>All Right @DMS</span>
      </footer>
    </div>
  );
};

export default FooterComponent;
